﻿
Example：
Zhang-embed.exe --no-asm --progress --analyse all --qp 15 --key 1234 --radius 3 --height 8 --rer 40 --logpath zhang_rer_log.txt  -o bus.264 bus.yuv 352x288

Steg-specific options:
--key: permutation key for MVs
--radius: search radius for Zhang et al.'s method
--height: sub-matrix height for STC
--rer: relative embedding rate (0< rer<50)
--bpf: bits per frame (bpf > 0, integer value)
--logpath：log path for embedding details
-o: 264 output path, YUV input path, video resolution

x264-specific options:
--no-asm: do not use hardware acceleration. This option must be added.
--progress: coding and embedding progress
--analyse all: use all partition types
--qp 15:  Quantization Parameter 15 (0 <= qp <= 51)
--bitrate 500: average bitrate 500kbps

The other x264 options are also acceptable.



